public class App {
    public static void main(String[] args) throws Exception {
        Ahorro persona1 = new Ahorro(98465451, "Jorge Sanchez");
        Ahorro persona2 = new Ahorro(15613513, "Diana Calderon");

        persona1.deposito(10000);
        persona2.deposito(10000);

        System.out.println(persona1.toString());
        System.out.println(persona2.toString());
    }
}
