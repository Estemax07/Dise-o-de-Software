package ejercicio3;

public class Estudiante {
    private String nombre;
    private int id;
}
