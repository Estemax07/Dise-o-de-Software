package ejercicio3;

import java.time.LocalDate;

public class Prestamo {
    private LocalDate fecha_prestamo;
    private LocalDate fecha_entrega;
    private char estado;
    private Libro libro;
    private Estudiante estudiante;
    private int dias_mora;
    private int multa;
}
