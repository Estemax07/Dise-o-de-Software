package ejercicio3;

public class Autor {
    private String nombre;
    private Pais pais;
    
    public Autor(String nombre, Pais pais){
        this.nombre = nombre;
        this.pais = pais;
    }
}
