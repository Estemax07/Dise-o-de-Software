package ejercicio3;

public class Libro {
    private int isbn;
    private String titulo;
    private int edicion;
    private Autor autor;
    private int npag;
    private Editorial editorial;
    private boolean prestar;
}
