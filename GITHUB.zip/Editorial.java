package ejercicio3;

public class Editorial {
    private int codigo;
    private String nombre;
    private Pais pais;
    
    public Editorial (int codigo, String nombre, Pais pais){
        this.codigo = codigo;
        this.nombre = nombre;
        this.pais = pais;
    }
}
